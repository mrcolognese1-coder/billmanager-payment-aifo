#!/usr/bin/php
<?php
/**
 * AIFO Result Handler for BILLmanager
 * Обробник результатів AIFO для BILLmanager
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

set_include_path(get_include_path() . PATH_SEPARATOR . "/usr/local/mgr5/include/php");
define('__MODULE__', "pmaifo");
require_once 'billmgr_util.php';

echo "Content-Type: text/html; charset=utf-8\n\n";

Debug('Вошли в файл aiforesult.php');
$params = CgiInput(true);

if (!function_exists('hash_equals')) {
    function hash_equals($str1, $str2) {
        if (strlen($str1) != strlen($str2)) return false;
        $res = $str1 ^ $str2;
        $ret = 0;
        for ($i = strlen($res) - 1; $i >= 0; $i--) {
            $ret |= ord($res[$i]);
        }
        return !$ret;
    }
}

if ($params) {
    $order_id = $params["invoice"];
    if (!$order_id) {
        Error('Empty order ID!');
        exit;
    }
    $info = LocalQuery("payment.info", array("elid" => $order_id));
    if ($info->payment->id) { //заказ существует в BM
        $sum = $params["sum"];
        $sum = $sum * 1;

        $paymethod_params = (array) $info->payment->paymethod[1];

        $merchant_id = $paymethod_params["merchant_id"];
        $secret_key = html_entity_decode($paymethod_params["secret_key"]);
        $signature_type = isset($paymethod_params["signature_type"]) ? (int)$paymethod_params["signature_type"] : 1; // 1=md5, 2=sha256, 3=sha1, 4=ripemd160, 5=sha384, 6=sha512

        // Генерация подписи в зависимости от типа
        $sign = '';
        if ($signature_type == 1) {
            $sign = md5($merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } elseif ($signature_type == 2) {
            $sign = hash('sha256', $merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } elseif ($signature_type == 3) {
            $sign = hash('sha1', $merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } elseif ($signature_type == 4) {
            $sign = hash('ripemd160', $merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } elseif ($signature_type == 5) {
            $sign = hash('sha384', $merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } elseif ($signature_type == 6) {
            $sign = hash('sha512', $merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        } else {
            $sign = md5($merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        }
        
        if (hash_equals($sign, $params['http_auth_signature'])) {
            LocalQuery("payment.setpaid", array("elid" => $order_id, 'externalid' => $order_id, 'info' => print_r($params, true)));
            Debug("payment.setpaid OK {$order_id}");
            echo("OK".$order_id);
            exit(0);
        } else {
            Error('Hash signature does not match');
            Error("merchant_id {$merchant_id} sum {$sum} secret_key {$secret_key} order_id {$order_id} sign {$sign}");
        }
    } else {
        Error("Order not found in BM!");
    }
} else {
    Error("Empty params!");
}
echo("ERROR");
?>

