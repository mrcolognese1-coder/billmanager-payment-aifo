#!/usr/bin/php
<?php
/**
 * AIFO Payment Module for BILLmanager
 * Модуль оплати AIFO для BILLmanager
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

set_include_path(get_include_path() . PATH_SEPARATOR . "/usr/local/mgr5/include/php");
define('__MODULE__', "pmaifo");
require_once 'billmgr_util.php';

echo "Content-Type: text/html; charset=utf-8\n\n";
$client_ip = ClientIp();
$param = CgiInput();

if (empty($param['elid'])) throw new Exception("EMPTY ELID!");

$info = LocalQuery("payment.info", array("elid" => $param["elid"]));

$elid = (string)$info->payment->id;

$sum = $info->payment->paymethodamount;
$sum = $sum * 1;

$paymethod_params = (array)$info->payment->paymethod[1];

$merchant_id = $paymethod_params["merchant_id"];
$secret_key = html_entity_decode($paymethod_params["secret_key"]);
$signature_type = isset($paymethod_params["signature_type"]) ? (int)$paymethod_params["signature_type"] : 1; // 1=md5, 2=sha256, 3=sha1, 4=ripemd160, 5=sha384, 6=sha512
$aifo_url = isset($paymethod_params["aifo_url"]) ? trim($paymethod_params["aifo_url"]) : 'https://test.aifo.pro';

$project_params = (array)$info->payment->project;

$order_name = $project_params["name"] . " #" . $elid;

$lang = _get_locale_lang("billmgrlang5");

if (is_null($lang)) {
    $lang = _get_locale_lang("billmgrlang6");
}

$lang = (is_null($lang)) ? 'uk' : $lang;

// Генерация подписи в зависимости от типа
$sign = '';
if ($signature_type == 1) {
    $sign = md5($merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} elseif ($signature_type == 2) {
    $sign = hash('sha256', $merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} elseif ($signature_type == 3) {
    $sign = hash('sha1', $merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} elseif ($signature_type == 4) {
    $sign = hash('ripemd160', $merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} elseif ($signature_type == 5) {
    $sign = hash('sha384', $merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} elseif ($signature_type == 6) {
    $sign = hash('sha512', $merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
} else {
    $sign = md5($merchant_id . ':' . $sum . ':' . $secret_key . ':' . $elid);
}

$params = array(
    'shop_id' => $merchant_id,
    'amount' => $sum,
    'id' => $elid, // Используем id вместо pay_id согласно API
    'desc' => $order_name, // Описание платежа
    'sign' => $sign
);

if (!empty($paymethod_params['paymentreceipt_type']) && $info->payment->items) {
    $params['gds'] = array();
    $payment_receipt_desc = $paymethod_params['payment_receipt_description'];
    foreach ($info->payment->items->item as $item) {
        $name = (string)$item->locale_name;
        if (stripos($name, 'Авансовый') !== false) {
            $name = $payment_receipt_desc;
        }
        $params['gds'][] = array(
            'name' => $name,
            'price' => (string)$item->amount,
            'quantity' => 1,
        );
    }
}

$inputs = '';
foreach ($params as $key => $value) {
    if ($key == 'gds') {
        foreach ($value as $index => $val) {
            $inputs .= '<input type="hidden" name="gds[' . $index . '][name]" value="' . htmlspecialchars($val['name']) . '">';
            $inputs .= '<input type="hidden" name="gds[' . $index . '][price]" value="' . $val['price'] . '">';
            $inputs .= '<input type="hidden" name="gds[' . $index . '][quantity]" value="' . $val['quantity'] . '">';
        }
    } else {
        $inputs .= '<input type="hidden" name="' . $key . '" value="' . htmlspecialchars($value) . '">';
    }
}

function _get_locale_lang($cookie_name)
{
    $lang = null;

    if (isset($_COOKIE[$cookie_name])) {
        Debug("Language by standart cookie");
        $cookie = $_COOKIE[$cookie_name];
        list($area, $lang) = explode(":", $cookie);
    } elseif (isset($_SERVER["HTTP_COOKIE"])) {
        Debug("Language by server cookie");
        $cookies = explode("; ", $_SERVER["HTTP_COOKIE"]);
        foreach ($cookies as $cookie) {
            $param_line = explode("=", $cookie);
            if (count($param_line) > 1 && $param_line[0] == $cookie_name) {
                list($area, $lang) = explode(":", $param_line[1]);
            }
        }
    }

    return $lang;
}

$payment_url = rtrim($aifo_url, '/') . '/pay/';

echo '
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<form name="payment_form" method="GET" action="' . htmlspecialchars($payment_url) . '">
' . $inputs . '
</form>
<script>document.payment_form.submit();</script>
</body>
</html>';

?>

